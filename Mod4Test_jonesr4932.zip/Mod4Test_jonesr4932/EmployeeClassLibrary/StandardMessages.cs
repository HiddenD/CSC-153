﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class StandardMessages
    {
        public static string DisplayMainMenu()
        {
            return "1. Create Employee Information\n2. Display Employee\n3. Exit\nEnter Choice: ";            
        }

        public static string ShowError()
        {
            return "Not A Valid Choice";
        }
    }
}
