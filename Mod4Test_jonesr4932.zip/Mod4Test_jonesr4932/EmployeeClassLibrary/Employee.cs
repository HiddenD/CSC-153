﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class Employee
    {

        //Fields
        private string _name;
        private string _phone;
        private string _age;

        //Constructor
        public Employee()
        {
            Name = "";
            Phone = "";
            Age = "";
        }

        public Employee (string name, string phone, string age)
        {
            Name = name;
            Phone = phone;
            Age = age;
        }

        //public Employee (int age)
        //{
        //    Age = 0;
        //}

        //Properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string Phone
        {
            get
            {
                return _phone;
            }
            set
            {
                _phone = value;
            }
        }

        public string Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }

        //Methods
        public void getName()
        {

        }
        public void getPhoneNumber()
        {

        }
        public void getAge()
        {
            int age;
            bool correct = Int32.TryParse(Age, out age);
            if (correct)
            {
                Console.WriteLine(Age);
            }
            else
            {
                Console.WriteLine("Error");
            }
        }
    }
}
