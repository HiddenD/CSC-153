﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeClassLibrary;

/*
 * April 1st, 2020
 * CSC 153
 * Reginald Jones
 * This program demostrates the Class and Single Responsivility
 */

// Class should have a Name, Phone, Age
// Program should make the user enter only one choice that will allow user to enter all 3 in one list
// Program should still display the results

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            Employee thisEmployee = new Employee();

            do
            {
                Console.WriteLine(StandardMessages.DisplayMainMenu());

                switch (Console.ReadLine())
                {
                    case "1":
                        CreateEmployee.CreateAEmployee(thisEmployee);
                        break;
                    case "2":
                        Console.WriteLine($"\nThis is the Infomation Entered: {thisEmployee.Name}, {thisEmployee.Phone}, {thisEmployee.Age}");
                        Console.ReadLine();
                        break;
                    case "3":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.ShowError());
                        break;
                }
            } while (exit == false);
        }
    }
}
