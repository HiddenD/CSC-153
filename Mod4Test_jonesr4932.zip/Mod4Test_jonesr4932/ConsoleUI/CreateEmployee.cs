﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeClassLibrary;

namespace ConsoleUI
{
    public class CreateEmployee
    {
        public static void CreateAEmployee(Employee inputEmployee)
        {
            Console.WriteLine("What is the Employee's Name? ->>> ");
            inputEmployee.Name = Console.ReadLine();

            Console.WriteLine("What is the Employee's Phone Number? ->>> ");
            inputEmployee.Phone = Console.ReadLine();

            Console.WriteLine("What is the Employee's Age? ->>> ");
            inputEmployee.Age = Console.ReadLine();
        }
    }
}
