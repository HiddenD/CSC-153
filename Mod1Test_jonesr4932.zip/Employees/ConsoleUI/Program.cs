﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * February 10, 2010
 * Reginald Jones
 * CSC 153
 * Example of Employee Program
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create input var for user input and sentry for loop
            string input;
            bool exit = false;

            //Create constant Var
            const int SIZE = 5;

            int nameIndex = 0, phoneIndex = 0;

            string[] employeeNames = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();

            do
            {
                Console.WriteLine("1. Enter Employee's Name.");
                Console.WriteLine("2. Enter Employee'd Phone Number.");
                Console.WriteLine("3. Enter Employee's Age.");
                Console.WriteLine("4. Display Employee's Information.");
                Console.WriteLine("5. Display Average Age of Employees.");
                Console.WriteLine("6. Exit");
                Console.Write("-->  ");
                input = Console.ReadLine();

                //Switch to direct to proper process
                switch (input)
                {

                    case "1":
                        Console.Write("Enter Employee's Name: ");
                        input = Console.ReadLine();
                        employeeNames[nameIndex] = input;
                        nameIndex++;
                        Console.WriteLine("");
                        break;

                    case "2":
                        Console.Write("Enter Employee's Phone Number:  ");
                        input = Console.ReadLine();
                        employeePhone[phoneIndex] = input;
                        phoneIndex++;
                        Console.WriteLine("");
                        break;

                    case "3":
                        int number = 0;
                        Console.Write("Enter Employee's Age:  ");
                        input = Console.ReadLine();

                        if(int.TryParse(input, out number))
                        {
                            employeeAge.Add(number);
                        }
                        else 
                        {
                            Console.WriteLine("Not a valid number!");
                        }
                        Console.WriteLine("");
                        break;

                    case "4":
                        for(int index = 0; index < employeeAge.Count; index++) 
                        {
                            Console.WriteLine($"Employee Name - {employeeNames[index]}");
                            Console.WriteLine($"Employee Phone - {employeePhone[index]}");
                            Console.WriteLine($"Employee Age - {employeeAge[index]}");
                            Console.WriteLine("");
                        }

                        break;
                    
                    case "5":
                        Console.WriteLine(employeeAge.Average());
                        Console.WriteLine("");
                        break;
                    
                    case "6":
                        exit = true;
                        break;
                    
                    default:
                        Console.WriteLine("Invalid Response");
                        break;
                }
                

            } while (exit == false);
        }
    }
}