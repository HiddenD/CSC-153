﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeClassLibrary;

/*
 * May 11th, 2020
 * CSC 153
 * Reginald Jones
 * 
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Sentry for Loop
            bool exit = false;

            List<Employee> employees = new List<Employee>();

            do
            {
                Console.WriteLine(StandardMessages.DisplayMainMenu());

                switch (Console.ReadLine())
                {
                    case "1":
                        CreateEmployee.CreateAEmployee(employees);
                        break;
                    
                    case "2":
                        DisplayEmployee.DisplayEmployeeInfo(employees);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;
                    
                    case "3":
                        DisplayEmployee.DisplayAverageAge(employees);
                        Console.WriteLine(StandardMessages.CleaningCode()); 
                        break;
                    
                    case "4":
                        Console.WriteLine(StandardMessages.DisplayExitMessage());
                        Console.WriteLine(StandardMessages.CleaningCode());
                        exit = true;
                        break;

                    //case "5":
                    //    Manager();
                    //    break;

                    default:
                        Console.WriteLine(StandardMessages.ShowError());
                        break;
                }
            } while (exit == false);
        }
    }
}
