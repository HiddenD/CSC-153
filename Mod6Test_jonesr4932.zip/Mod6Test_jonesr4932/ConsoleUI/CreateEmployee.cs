﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeClassLibrary;

namespace ConsoleUI
{
    public class CreateEmployee
    {
        public static void CreateAEmployee(List<Employee> inputList)
        {
            bool correct = false;

            Employee output = new Employee();

            Console.WriteLine(StandardMessages.GetEmployeeName());
            output.Name = Console.ReadLine();

            Console.WriteLine(StandardMessages.GetEmployeePhoneNum());
            output.PhoneNumber = Console.ReadLine();

            Console.WriteLine(StandardMessages.GetEmail());
            Console.WriteLine($"{output.Name}@worker.com");
            Console.ReadLine();

            do
            {
                Console.WriteLine(StandardMessages.GetEmployeeAge());
                output.Age = TryParse.ParseToInt(Console.ReadLine());

                if (output.Age >= 18)
                {
                    correct = true;
                }
                else
                {
                    Console.WriteLine(StandardMessages.DisplayAgeError());
                }

            } while (correct == false);

            inputList.Add(output);
        }
    }
}
