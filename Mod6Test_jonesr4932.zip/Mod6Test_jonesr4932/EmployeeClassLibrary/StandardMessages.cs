﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class StandardMessages
    {
        public static string DisplayMainMenu()
        {
            return "1. Create Employee Information\n2. Display Employee\n3. Display Employee Age\n4. Exit."+
                "\nEnter Choice: ";            
        }

        public static string GetEmployeeName()
        {
            return "Enter Employee's Name: ";
        }

        public static string GetEmployeePhoneNum()
        {
            return "Enter Employee's Phone Number: ";
        }

        public static string GetEmail()
        {
            return "Your Email is: ";
        }

        public static string GetEmployeeAge()
        {
            return "Enter Employee's Age: ";
        }

        public static string DisplayExitMessage()
        {
            return "Goodbye.";
        }

        public static string CleaningCode()
        {
            return " ";
        }

        public static string ShowError()
        {
            return "Not A Valid Choice";
        }

        public static string DisplayAgeError()
        {
            return "Must be 18 or older, Please Re-enter Age: ";
        }
    }
}
