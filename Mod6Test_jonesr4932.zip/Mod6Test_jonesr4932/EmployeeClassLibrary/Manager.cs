﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class Manager : Employee
    {
        //Field
        private string _name;
        private string _phoneNumber;
        private int _age;

        //Constructor
        public Manager(string name, string phoneNumber, int age) : base("Steven", "555-5555", 36, "")
        {
            Name = name;
            PhoneNumber = phoneNumber;
            Age = age;
        }

        //Name Property
        public new string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public new string PhoneNumber
        {
            get { return _phoneNumber; }
            set { _phoneNumber = value; }
        }

        public new int Age
        {
            get { return _age; }
            set { _age = value; }
        }

        public override string CreateEmail()
        {
            return "@manager.com";
        }
    }
}
