﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonAndCustomerLibrary
{
    //Information for the Customer Class
    //It's Deriving Information from Person Class while adding additional information
    public class Customer : Person
    {
        public int CustomerNumber { get; set; }
        public bool MailingList { get; set; }

    }
}
