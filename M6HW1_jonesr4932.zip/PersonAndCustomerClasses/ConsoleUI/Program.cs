﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PersonAndCustomerLibrary;

/*
 * May 1th, 2020
 * CSC 153
 * Reginald Jones
 * This is to showcase the use of Classes
 */

/*
 * Instruction:
 * Design a class named Person with the properties for holding a person;s name, address, and telephone number.
 * Next, design a class named Customer, which is derived from the Person class.
 * The Customer class should have a property for a customer number and a Boolean property indicating weather the customer wishes to be on a mailing list.
 * Demonstrate an object of the Customer class in a simple console application.
 */

namespace ConsoleUI
{
    public class Program
    {
        //Simple Program Run
        public static void Main(string[] args)
        {
            //Calls infomation from the Customer Class, which also pulls information from Person Class
            Customer customer = new Customer();
            customer.Name = "Charles Garcia";
            customer.CustomerNumber = 25;
            customer.Address = "123 Fake St.";
            customer.MailingList = false;

            Console.WriteLine("An example of the Derivated Class, Using Customer as the basis");
            Console.WriteLine($"\nCustomer's Name is {customer.Name}");
            Console.WriteLine($"Customer's Number is {customer.CustomerNumber}");
            Console.WriteLine($"Customer's Address is {customer.Address}");
            Console.WriteLine($"Does the Customer want to be on the Mailing List? {customer.MailingList}");
            Console.ReadLine();
        }
    }
}
