﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * February 13, 2020
 * CSC 153
 * Reginald Jones
 * Creating a Program that takes an Array with Values and Displays them.
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //An Array is Created with 7 Values
            string[] values = { "1245.67", "1189.55", "1098.72", "1456.88", "2109.34", "1987.55", "1872.36" };

            //Displays the Values
            Console.WriteLine(values[0]);
            Console.WriteLine(values[1]);
            Console.WriteLine(values[2]);
            Console.WriteLine(values[3]);
            Console.WriteLine(values[4]);
            Console.WriteLine(values[5]);
            Console.WriteLine(values[6]);
            Console.ReadLine();

        }
    }
}
