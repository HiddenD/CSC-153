﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarClassLibrary;
/*
 * March 30th, 2020
 * CSC 153
 * Reginald Jones
 * This Program is to Allow the User To Create a Car and Run a small test on it.
 */

//Instructions:
//Create a class named Car that has the following properties:

//Year - The Year property holds the car's year model.
//Make - The Make property holds the make of the car.
//Speed - The Speed property holds the car's current speed.
//In addition, the class should have the following constructor and other methods:

//Constructor - The constructor should accept the car's year and model and take them as arguments. 
//Accelerate - The Accelerate method should add 5 to the Speed property's backing field each time it is called.
//Brake - The Brake method should subtract 5 from the Speed property's backing field each time it is called.
//Demonstrate the class in an application that creates a Car object. 

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            Car thisCar = new Car();

            //Switch Statement for Menu
            do
            {
                Console.WriteLine(StandardMessages.DisplayMainMenu());
                
                switch(Console.ReadLine())
                {
                    case "1":
                        BuildCar.BuildACar(thisCar);
                        break;
                    case "2":
                        thisCar.Accelerate();
                        break;
                    case "3":
                        thisCar.Brake();
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.ShowChoiceError());
                        break;
                }
                
                //Information on the Current Speed
                Console.WriteLine($"The car is going {thisCar.Speed} MPH");

            } while (exit == false);
        }
    }
}