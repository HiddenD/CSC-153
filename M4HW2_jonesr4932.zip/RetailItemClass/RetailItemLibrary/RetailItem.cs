﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//This Library which holds information for the items.
namespace RetailItemLibrary
{
    public class RetailItem
    {
        // Fields
        private string _description;
        private int _unitsonhand;
        private double _price;

        //Contructors
        public RetailItem()
        {
            Description = "";
            UnitsOnHand = 0;
            Price = 0.00;
        }

        public RetailItem(string desciption, int unitsonhand, double price)
        {
            Description = desciption;
            UnitsOnHand = unitsonhand;
            Price = price;
        }

        //Properties
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        public int UnitsOnHand
        {
            get { return _unitsonhand; }
            set { _unitsonhand = value; }
        }
        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }


        //Methods
        public static void RetailItemList()
        {
            //Created List for the Items
            List<string> list1 = new List<string>();
            List<int> list2 = new List<int>();
            List<double> list3 = new List<double>();

            list1.Add("Jacket");
            list1.Add("Jeans");
            list1.Add("Shirt");

            list2.Add(12);
            list2.Add(40);
            list2.Add(20);

            list3.Add(59.05);
            list3.Add(34.95);
            list3.Add(24.95);

            //Foreach Loop to run the Lists
            //Student Note: Need to fix and find another option to display items properly.
            //Combining lists with different datatypes will not work.

            foreach (string item in list1)
            {
                Console.WriteLine($"\nItem Description: {item}.");
            }

            foreach (int item in list2)
            {
                Console.WriteLine($"\nInventory Count: {item}");
            }
            
            foreach (double item in list3)
            {
                Console.WriteLine($"\nPrice: ${item}");
            }

            Console.ReadLine();
        }
    }
}