﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailItemLibrary;

/*
 * April 7th, 2020
 * CSC 153
 * Reginald Jones
 * A Program that is to run and display items from a retail market.
 */

/*
 * Write a class RetailItem that holds data about an item in a retail store. The class should have the following properties:

 * Description - The Description property should hold a brief description of the item.
 * UnitsOnHand - The UnitOnHand property should hold the number of units currently in inventory.
 * Price - The Price property should hold the item's retail price.
 * Write a constructor that accepts arguments for each property.

 * The application should create a list of three RetailItem objects containing the following data:

 * Description, Units on Hand, Price
 * Jacket, 12, $59.05
 * Jeans, 40, $34.95
 * Shirt, 20, $24.95
 * The application should loop through the list, displaying each element's property in a readable format.
 */

namespace ConsoleUI
{
    class Program
    {
        public static void Main(string[] args)
        {
            //Sentry to Run Program
            bool exit = false;

            do
            {
                //Switch For Menu
                Console.WriteLine(DisplayMainMenu());

                switch(Console.ReadLine())
                {
                    case "1":
                        RetailItem.RetailItemList();
                        break;

                    case "2":
                        exit = true;
                        break;

                    default:
                        Console.WriteLine(DisplayError());
                        break;
                }

            } while (exit == false);
        }

        //Main Menu
        public static string DisplayMainMenu()
        {
            return "RetailItemClass Program.\n1. Run Program\n2. Exit Program" +
                "\n\nPlease Select An Option:  ";
        }

        //Menu Error Display
        public static string DisplayError()
        {
            return "\nInvalid Selection.";
        }
    }
}