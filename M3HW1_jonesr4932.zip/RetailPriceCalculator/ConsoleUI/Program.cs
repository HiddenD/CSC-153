﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * March 1st, 2020
 * CSC 153
 * Reginald Jones
 * The program is to markup a Sales' price and Display the percentage taken.
 */

/* Instructions:

Create an application that lets the user enter an items wholesale cost and its markup percentage. It should then display the item's price. For example,

If the item's wholesale cost is $5.00 and its markup percentage is 100 percent, then the item's retail price is $10.00.
If an item's wholesale cost is $5.00 and its markup percentage is 50 percent, then the item's retail price is $7.50.
The program should have a method named CalculateRetail that receives the wholesale cost and the markup percentage as arguments and returns the retail price of the item
*/

namespace ConsoleUI
{
    class Program
    {
        public static void Main(string[] args)
        {
            //User Input
            string input;
            bool exit = false;

           // List<int> retailPrice = new List<int>();
            
            //Switch Statement for Menu
            do 
            { 
                Console.Write(DisplayMenu());
                input = Console.ReadLine();
                
                switch (input)
                {
                    case "1":
                        Console.WriteLine(CalculateRetail(input));
                        Console.ReadLine();
                        break;

                    case "2":
                        exit = true;
                        break;

                    default:
                        Console.WriteLine(DisplayError());
                        break;                    
                
                }
            } while (exit == false);
        }

        //Main Menu
        public static string DisplayMenu()
        {
            return "This Is a Retail Calculator Application\n\n1. Run Program\n2. Exit Program" +
                "\n\nPlease Enter Select An Option:  ";
        }

        //Method to Calculate Retail Price and Markup
        //Student Note: Need to Adjust the Double function for the Prices
        //Gives incorrect Output.

        public static int CalculateRetail(string input) 
        {
            //Converts String to Double
            Console.Write("Enter Retail Price:  ");
            double price = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter Markup Percentage: ");
            double percent = Convert.ToDouble(Console.ReadLine());

            //Placeholder for Final Markup Price
            double finalmark;

            finalmark = price * percent;

            Console.WriteLine($"The Retail Price is ${finalmark.ToString()}");
            return 0;

            //input = Console.ReadLine();
            //int output = 0;
            //if (int.TryParse(input, out output))
            //{
            //    return output;
            //}
            //else
            //{
            //    Console.WriteLine($"Retail Price is { input }.");
            //    return output;
            //}

        }
        //Menu Error Display
        static string DisplayError()
        {
            return "\nNot A Valid Number!";
        }
    }
}
