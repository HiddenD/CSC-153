﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * February 19th, 2020
 * CSC 153
 * Reginald Jones
 * Text Adventure Game, This is the First Part of it.
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {

            bool exit = false;

            const int SIZE = 5;

            int roomIndex = 0, weaponIndex = 0, potionIndex = 0, treasureIndex = 0;

            string[] dungeonRoom = new string[SIZE];
            string[] dungeonWeapon = new string[SIZE];
            string[] dungeonPotion = new string[SIZE];
            string[] dungeonTreasure = new string[SIZE];
            List<string> dungeonMob = new List<string>();


            do
            {
                Menu();
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Room();
                        break;
                    case "2":
                        Weapon();
                        break;
                    case "3":
                        Potion();
                        break;
                    case "4":
                        Treasure();
                        break;
                    case "5":
                        Items();
                        break;
                    case "6":
                        Mobs();
                        break;
                    case "7":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("\nInvalid Command");
                        Console.WriteLine();
                        break;
                }

            } while (exit == false);

        }

        public static void Menu() 
        {
            Console.WriteLine("1. Display Rooms");
            Console.WriteLine("2. Display Weapon");
            Console.WriteLine("3. Display Potion");
            Console.WriteLine("4. Display Treasure");
            Console.WriteLine("5. Display Items");
            Console.WriteLine("6. Display Mobs");
            Console.WriteLine("7. Exit");
            Console.Write("\nPlease Enter A Number:  ");
        }

        public static void Room() 
        { 
        
        }

        public static void Weapon()
        {

        }

        public static void Treasure()
        {

        }

        public static void Items()
        {
            List<string> dungeonItem = new List<string>();
            dungeonItem.Add("Chain of Memories");
            Console.WriteLine($"\nItems Are { dungeonItem[0]}");

        }

        public static void Mobs()
        {

        }

        public static void Potion()
        {

        }
    }
}