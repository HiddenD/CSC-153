﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * March 4th, 2020
 * CSC 153
 * Reginald Jones
 * A Program to measure the Falling Distance of an Object in Seconds and Display Results. 
 */

//Falling Distance Formula: h = 1/2gt^2
//Notes: h is the distance in meters, g is 9.8, t is the amount of time in seconds

//Instructions: Create an application that allows the user to enter the amount of time that and object has fallen and then display the distance the object fell.
//The application should have a method named FallingDistance. The FallingDistance method should accept an object's falling time (in seconds) as an argument. 
//The method should return the distance in meters that the object has fallen during that time interval.

namespace ConsoleUI
{
    class Program
    {
        public static void Main(string[] args)
        {

            //For User Input
            string input;
            bool exit = false;

            do
            {
                //Menu
                Console.WriteLine(DisplayMenu());
                input = Console.ReadLine();

                switch (input)
                {
                    //1 Will Start the Program
                    case "1":
                        Console.WriteLine(FallingDistance(input));
                        break;

                    //2 Will End the Program
                    case "2":
                        exit = true;
                        break;

                    default:
                        Console.WriteLine(DisplayError());
                        break;
                
                }

            }while (exit == false);

        }

        //Method for the Menu
        public static string DisplayMenu()
        {
            return "Falling Distance Program\n\n1. Start Program\n2. Exit Program" +
                "\n\nPlease Enter An Option: ";
        }

        //Method for the Program
        public static string FallingDistance(string input)
        {
            Console.Write("Enter The Amount of Seconds: ");
            //Converts the input into a Double
            double time = Convert.ToDouble(Console.ReadLine());

            //Formulas needed for the calculation
            double distance;
            const double gravity = 9.8;
            const double fraction = .5;
            double squared = Math.Pow((time * gravity), 2.0);
            distance = fraction * squared;

            //Result
            Console.WriteLine($"The Amount of Distance is {distance.ToString()} meters.");
            return Console.ReadLine();
        }

        //Method for Error Catching in the Menu
        public static string DisplayError()
        {
            return "\nNot A Valid Choice.";
        }

    }
}