﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * February 15, 2020
 * CSC 153
 * Reginald Jones
 * This Program Asks to Enter Ages And Displays Them To The User.
 */


//Student Note: Program Runs, But Does Not Display The Ages.

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do 
            {
                Console.WriteLine("1. Run Program ");
                Console.WriteLine("2. Exit Program");
                Console.Write("Enter 1 or 2:  ");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    Console.WriteLine("Enter the Ages You Wish To Input, -1 To Exit");
                    Console.Write("Enter Age:  ");

                    do
                    {
                        List<int> ageList = new List<int>();

                        int count = 0;
                        input = Console.ReadLine();

                        if (int.TryParse(input, out count))
                        {
                            for (int index = 0; index < ageList.Count(); index++)
                            {
                                Console.WriteLine($"You Choosen {ageList}");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid Command!");
                        }


                    } while (input != "-1");

                }

                else if (input == "2")
                {
                    exit = true;
                }

                else
                {
                    Console.WriteLine("Invalid Command.");
                }

            } while (exit == false);
        }
    }
}
