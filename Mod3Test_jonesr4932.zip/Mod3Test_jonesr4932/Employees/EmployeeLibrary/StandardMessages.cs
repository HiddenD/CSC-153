﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Class Library for Employee Program
namespace EmployeeLibrary
{
    public static class StandardMessages
    {

        public static string DisplayMenu()
        {
            return "1. Enter Employee's Name\n2. Enter Employee's Phone Number\n" +
                "3. Enter Employee's Age\n4. Display Employee's Information\n" +
                "5. Display Average Age of Employees\n6. Exit\n-------- ";
        }

        //Getting User Input
        public static string GetUserInput(string input)
        {
            Console.Write(input);
            return Console.ReadLine();
        }

        public static string EnterName()
        {
            return "Enter Employee's Name ---> ";
        }

        public static string EnterNumber()
        {
            return "Enter Phone Number ---> ";
        }

        public static string EnterAge()
        {
            return "Enter Age ---> ";
        }

        /*public static string DisplayAge()
        {
            return "Nothing";

        }

        public static string DisplayAverageAge()
        {
            return "Nothing";

        }*/

        public static string DisplayError()
        {
            return "Not A Valid Number!";
        }

        public static string DisplayEmployee(string[] name, string[] phone, List<int> age, int index)
        {
            return $"Employee Name- {name[index]}\n" +
                $"Employee Phone- {phone[index]}\n" +
                $"Employee Age- {age[index]}";
        }
    }
}