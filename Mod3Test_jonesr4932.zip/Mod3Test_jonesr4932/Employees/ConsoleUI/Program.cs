﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * February 5th 2020
 * CSC 153
 * Reginald Jones
 * This program is to allow the user to navagate through the options
 * and enter information based on what the user chooses.
 */

namespace ConsoleUI
{
    class Program
    {
        public static void Main(string[] args)
        {
            string input;
            bool exit = false;

            const int SIZE = 5;
            int nameIndex = 0, phoneIndex = 0;
            string[] employeeName = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();

            do
            {
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayMenu());
                input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        Console.Write(EmployeeLibrary.StandardMessages.EnterName());
                        input = Console.ReadLine();
                        employeeName[nameIndex] = input;
                        nameIndex++;
                        Console.WriteLine();
                        break;

                    case "2":
                        Console.Write(EmployeeLibrary.StandardMessages.EnterNumber());
                        input = Console.ReadLine();
                        employeeName[phoneIndex] = input;
                        nameIndex++;
                        Console.WriteLine();
                        break;

                    case "3":
                        int number = 0;
                        Console.WriteLine(EmployeeLibrary.StandardMessages.EnterAge());
                        input = Console.ReadLine();
                        if (int.TryParse(input, out number)) 
                        {
                            employeeAge.Add(number);
                        }
                        else
                        {
                            Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayError());
                        }
                        break;

                    case "4":
                        for (int index = 0; index < employeeAge.Count; index++)
                        {
                            Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayEmployee(employeeName, employeePhone, employeeAge, index));
                        }
                        Console.WriteLine();
                        break;

                    case "5":
                        Console.WriteLine(employeeAge.Average());
                        Console.WriteLine();
                        break;

                    case "6":
                        exit = true;
                        break;

                    default:
                        Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayError());
                        Console.WriteLine();
                        break;
                }
            } while (exit == false);
        }
    }
}